const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const studentRoutes = require('./routes/studentRoutes.js'); // Adjust the path as necessary

// Initialize the app
const app = express();

app.use(cors());

// Middleware
app.use(bodyParser.json());

// Routes
app.use('/api/students', studentRoutes);

/*// MongoDB connection
const mongoURI = 'mongodb+srv://RohanGoshiv:FgRbSLGmXqlItCSR@cluster0.zhsmx.mongodb.net/'; // Replace with your MongoDB URI
mongoose.connect(mongoURI, { useNewUrlParser: true, useUnifiedTopology: true })
    .then(() => console.log('MongoDB connected'))
    .catch((err) => console.log(err));*/

    mongoose.connect('mongodb://localhost:27017/student-management')
  .then(() => console.log('Connected to MongoDB'))
  .catch(err => console.error('MongoDB connection error:', err));


// Start the server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});

