const express = require('express');
const router = express.Router();
const Student = require('../models/student.js'); // Adjust the path as necessary

// Middleware to fetch a student by ID
const getStudent = async (req, res, next) => {
    let student;
    try {
        student = await Student.findById(req.params.id);
        if (!student) {
            return res.status(404).json({ message: 'Student not found' });
        }
    } catch (err) {
        return res.status(500).json({ message: err.message });
    }
    res.student = student;
    next();
};

// Get all students
router.get('/', async (req, res) => { 
    try {
        const students = await Student.find();
        res.json(students);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

// Get a student by ID
router.get('/:id', getStudent, (req, res) => {
    res.json(res.student);
});

// Add a new student
router.post('/', async (req, res) => {
    const { name, email, phone } = req.body;
    const newStudent = new Student({
        name,
        email,
        phone,
    });
    try {
        const savedStudent = await newStudent.save();
        res.status(201).json(savedStudent);
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});

// Update a student by ID
router.put('/:id', getStudent, async (req, res) => {
    const { name, email, phone } = req.body;

    try {
        const updatedStudent = await Student.findByIdAndUpdate(
            req.params.id,
            { name, email, phone },
            { new: true, runValidators: true }
        );

        if (!updatedStudent) {
            return res.status(404).json({ message: 'Student not found' });
        }

        res.json(updatedStudent);
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});

// Delete a student by ID
router.delete('/:id', getStudent, async (req, res) => {
    try {
        await res.student.remove();
        res.json({ message: 'Student deleted' });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

module.exports = router;
