import React, { useState, useEffect } from 'react';
import axios from 'axios';

function App() {
  const [students, setStudents] = useState([]);
  const [form, setForm] = useState({ name: '', email: '', phone: '' });
  const [editingId, setEditingId] = useState(null);

  const API_URL = 'http://localhost:5000/api/students'; // Your backend endpoint

  // Fetch students when component mounts
  useEffect(() => {
    fetchStudents();
  }, []);

  const fetchStudents = async () => {
    try {
      const res = await axios.get(API_URL);
      setStudents(res.data);
    } catch (err) {
      console.error(err);
      alert('Error fetching students');
    }
  };

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

 /* const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (editingId) {
        // Update existing student
        await axios.put(`${API_URL}/${editingId}`, form);
      } else {
        // Create new student
        await axios.post(API_URL, form);
      }
      setForm({ name: '', email: '', phone: '' });
      setEditingId(null);
      fetchStudents();
    } catch (err) {
      console.error(err);
      alert('Error saving student');
    }
  };
  */

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (editingId) {
        await axios.put(`${API_URL}/${editingId}`, form);
      } else {
        await axios.post(API_URL, form);
      }
      setForm({ name: '', email: '', phone: '' });
      setEditingId(null);
      fetchStudents();
    } catch (err) {
      console.error(err);
      if (err.response && err.response.data && err.response.data.message) {
        alert(`Error: ${err.response.data.message}`);
      } else {
        alert('Unknown error saving student');
      }
    }
  };
  


  const handleEdit = (student) => {
    setForm({ name: student.name, email: student.email, phone: student.phone });
    setEditingId(student._id);
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Are you sure you want to delete this student?')) return;
    try {
      await axios.delete(`${API_URL}/${id}`);
      fetchStudents();
    } catch (err) {
      console.error(err);
      alert('Error deleting student');
    }
  };

  return (
    <div style={{ maxWidth: '600px', margin: '50px auto', padding: '20px' }}>
      <h1>Student Management</h1>

      {/* Student Form */}
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          name="name"
          placeholder="Name"
          value={form.name}
          onChange={handleChange}
          required
          style={{ width: '100%', marginBottom: '10px', padding: '8px' }}
        />
        <input
          type="email"
          name="email"
          placeholder="Email"
          value={form.email}
          onChange={handleChange}
          required
          style={{ width: '100%', marginBottom: '10px', padding: '8px' }}
        />
        <input
          type="text"
          name="phone"
          placeholder="Phone"
          value={form.phone}
          onChange={handleChange}
          required
          style={{ width: '100%', marginBottom: '10px', padding: '8px' }}
        />
        <button type="submit" style={{ padding: '10px 20px', marginBottom: '20px' }}>
          {editingId ? 'Update Student' : 'Add Student'}
        </button>
      </form>

      {/* Student List */}
      <ul style={{ listStyle: 'none', padding: 0 }}>
        {students.map((student) => (
          <li
            key={student._id}
            style={{
              marginBottom: '15px',
              padding: '10px',
              border: '1px solid #ccc',
              borderRadius: '5px',
            }}
          >
            <p><strong>{student.name}</strong></p>
            <p>{student.email}</p>
            <p>{student.phone}</p>
            <button onClick={() => handleEdit(student)} style={{ marginRight: '10px' }}>
              Edit
            </button>
            <button onClick={() => handleDelete(student._id)}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default App;
